import astropy.units as u
import numpy as np
import pytest

from divtel.telescope import Array, Telescope


@pytest.fixture
def hess_1():
    """Four telescopes on a 100 m square, all pointing at the zenith."""
    array = Array(
        [
            Telescope(100 * u.m, 0 * u.m, 0 * u.m, 20 * u.m, 1 * u.m),
            Telescope(0 * u.m, 100 * u.m, 0 * u.m, 20 * u.m, 1 * u.m),
            Telescope(-100 * u.m, 0 * u.m, 0 * u.m, 20 * u.m, 1 * u.m),
            Telescope(0 * u.m, -100 * u.m, 0 * u.m, 20 * u.m, 1 * u.m),
        ]
    )
    for telescope in array.telescopes:
        telescope.point_to_altaz(90 * u.deg, 0 * u.deg)
    return array


def single_disc_area(array):
    """Exact area of one camera's spherical cap, in deg**2."""
    radius = array.telescopes[0].fov_radius.to_value(u.rad)
    steradians = 2 * np.pi * (1 - np.cos(radius))
    return steradians * np.degrees(1.0) ** 2


def test_fov_radius_matches_fov_area():
    """The angular radius and the field of view area describe the same cone."""
    telescope = Telescope(0 * u.m, 0 * u.m, 0 * u.m, 20 * u.m, 1 * u.m)
    radius = telescope.fov_radius.to_value(u.rad)
    # `fov` uses the small-angle form, so agreement is close but not exact.
    assert np.pi * radius**2 == pytest.approx(telescope.fov.to_value(u.rad**2),
                                              rel=1e-2)


def test_parallel_pointing_is_one_camera_seen_by_all(hess_1):
    """With no divergence every disc coincides: one patch, full multiplicity."""
    hess_1.divergent_pointing(0, 70 * u.deg, 0 * u.deg)
    area, patches = hess_1.hyper_fov(m_cut=1)

    assert len(patches) == 1
    assert patches[0][1] == len(hess_1.telescopes)
    assert area.to_value(u.deg**2) == pytest.approx(single_disc_area(hess_1),
                                                    rel=1e-3)


def test_full_divergence_is_every_camera_seen_alone(hess_1):
    """Fully divergent, the discs are disjoint and nothing is seen twice."""
    hess_1.divergent_pointing(1, 70 * u.deg, 0 * u.deg)
    area, patches = hess_1.hyper_fov(m_cut=1)
    n = len(hess_1.telescopes)

    assert len(patches) == n
    assert {m for _, m in patches} == {1}
    assert area.to_value(u.deg**2) == pytest.approx(n * single_disc_area(hess_1),
                                                    rel=1e-3)
    # Nothing overlaps, so there is no stereoscopic coverage at all.
    assert hess_1.hyper_fov(m_cut=2)[0].to_value(u.deg**2) == pytest.approx(0)


def test_divergence_widens_coverage(hess_1):
    """Coverage grows with divergence, between the two limits above."""
    areas = []
    for div in (0.0, 0.01, 0.02, 0.05):
        hess_1.divergent_pointing(div, 70 * u.deg, 0 * u.deg)
        areas.append(hess_1.hyper_fov(m_cut=1)[0].to_value(u.deg**2))

    assert areas == sorted(areas)
    assert areas[0] == pytest.approx(single_disc_area(hess_1), rel=1e-3)
    assert areas[-1] <= 4 * single_disc_area(hess_1) * 1.001


def test_m_cut_selects_a_subset(hess_1):
    """A higher multiplicity cut can only ever count less sky."""
    hess_1.divergent_pointing(0.008, 70 * u.deg, 0 * u.deg)

    covered = hess_1.hyper_fov(m_cut=1)[0]
    stereo = hess_1.hyper_fov(m_cut=2)[0]
    quadruple = hess_1.hyper_fov(m_cut=4)[0]

    assert covered > stereo > quadruple > 0 * u.deg**2

    # The cut changes the area reported, never the patches returned.
    assert len(hess_1.hyper_fov(m_cut=1)[1]) == len(hess_1.hyper_fov(m_cut=4)[1])


def test_patches_partition_the_covered_area(hess_1):
    """The patches tile the union: no gaps, no double counting."""
    hess_1.divergent_pointing(0.01, 70 * u.deg, 0 * u.deg)
    area, patches = hess_1.hyper_fov(m_cut=1)

    assert sum(p.area for p, _ in patches) == pytest.approx(
        area.to_value(u.deg**2)
    )
    for patch, _ in patches:
        for other, _ in patches:
            if patch is not other:
                assert patch.intersection(other).area == pytest.approx(0, abs=1e-9)


def test_azimuth_wrap_is_unwrapped(hess_1):
    """An array straddling due north is not torn in half by the 0/360 seam."""
    for telescope in hess_1.telescopes:
        telescope.point_to_altaz(70 * u.deg, 0 * u.deg)
    # Nudge two telescopes either side of the seam.
    hess_1.telescopes[0].point_to_altaz(70 * u.deg, 359 * u.deg)
    hess_1.telescopes[1].point_to_altaz(70 * u.deg, 1 * u.deg)

    area, patches = hess_1.hyper_fov(m_cut=1)
    # Those two discs are 2 deg apart and 5.7 deg across, so they must overlap.
    assert max(m for _, m in patches) >= 2
    assert area.to_value(u.deg**2) < 4 * single_disc_area(hess_1)


def test_zenith_pointing_still_overlaps(hess_1):
    """Near the zenith the discs overlap as much as anywhere else.

    Azimuth converges at the pole, so telescopes a fraction of a degree apart
    on the sky can be hundreds of degrees apart in azimuth. Doing the geometry
    in the (azimuth, altitude) plane put these four discs 270 degrees apart and
    reported four separate patches of sky where there is very nearly one.
    """
    hess_1.divergent_pointing(0.005, 90 * u.deg, 0 * u.deg)

    directions = hess_1.pointing_vectors
    separations = [
        np.degrees(np.arccos(np.clip(directions[i] @ directions[j], -1, 1)))
        for i in range(len(directions))
        for j in range(i + 1, len(directions))
    ]
    fov_radius = hess_1.telescopes[0].fov_radius.to_value(u.deg)
    assert max(separations) < fov_radius, "premise: the discs must overlap"

    area, patches = hess_1.hyper_fov(m_cut=1)
    assert max(m for _, m in patches) == len(hess_1.telescopes)
    # Barely more than one camera's worth of sky, not four.
    assert area.to_value(u.deg**2) < 1.4 * single_disc_area(hess_1)


def test_zenith_matches_an_equivalent_lower_pointing(hess_1):
    """The same array is the same size wherever it is pointed."""
    hess_1.divergent_pointing(0, 90 * u.deg, 0 * u.deg)
    at_zenith = hess_1.hyper_fov(m_cut=1)[0]

    hess_1.divergent_pointing(0, 20 * u.deg, 137 * u.deg)
    low = hess_1.hyper_fov(m_cut=1)[0]

    assert at_zenith.to_value(u.deg**2) == pytest.approx(
        low.to_value(u.deg**2), rel=1e-6
    )


def test_no_patch_is_seen_by_nobody(hess_1):
    """A ring of discs encloses a hole; it is not part of the field of view."""
    for div in (0.005, 0.02, 0.05, 0.1, 0.3):
        hess_1.divergent_pointing(div, 90 * u.deg, 0 * u.deg)
        _, patches = hess_1.hyper_fov(m_cut=1)
        assert all(m >= 1 for _, m in patches), f"multiplicity 0 patch at div={div}"


def test_sky_map_orientation_is_continuous_across_the_pointing_range():
    """
    Regression test for a real bug: an earlier implementation built the sky
    map's tangent-plane basis from a fixed external axis, switched between two
    choices depending on which the pointing was closer to. Crossing that
    switch flipped the whole projected map by 90 degrees for an
    infinitesimal change in pointing -- an asymmetric array's projected
    bounding box would swap its width and height in one step. Sweeping the
    mean pointing's altitude through where that switch used to sit (~26 deg,
    for an array pointed due north) should move the bounding box smoothly.
    """
    # Elongated on the ground, so the projected bounding box is asymmetric
    # and a 90-degree flip is visible as width and height swapping.
    array = Array([
        Telescope(x * u.m, y * u.m, 0 * u.m, 20 * u.m, 1 * u.m)
        for x, y in [(-300, -20), (-150, 20), (0, -20), (150, 20), (300, -20)]
    ])

    widths, heights = [], []
    for alt in np.linspace(15, 40, 60):
        array.divergent_pointing(0.03, alt * u.deg, 0 * u.deg)
        _, patches = array.hyper_fov(rim_points=48)
        xs = np.concatenate([np.array(p.exterior.coords)[:, 0] for p, m in patches])
        ys = np.concatenate([np.array(p.exterior.coords)[:, 1] for p, m in patches])
        widths.append(xs.max() - xs.min())
        heights.append(ys.max() - ys.min())

    assert np.abs(np.diff(widths)).max() < 0.5
    assert np.abs(np.diff(heights)).max() < 0.5
